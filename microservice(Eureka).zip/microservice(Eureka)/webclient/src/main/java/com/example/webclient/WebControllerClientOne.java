package com.example.webclient;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WebControllerClientOne 
{

	@GetMapping("/students")
	private List<StudentBean> getMyStudentDetails() 
	{
		List<StudentBean> list = new ArrayList<StudentBean>();
		list.add(new StudentBean(101, "kalai", "200"));
		list.add(new StudentBean(102, "Abi", "400"));
		list.add(new StudentBean(103, "priya", "500"));
		list.add(new StudentBean(104, "gowtham", "600"));
		return list;
	}
	
	
}
