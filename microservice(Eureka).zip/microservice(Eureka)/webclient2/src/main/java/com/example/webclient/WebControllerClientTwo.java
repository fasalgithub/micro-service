package com.example.webclient;

import java.lang.reflect.ParameterizedType;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

@RestController
public class WebControllerClientTwo 
{

	
	@Autowired
	RestTemplate template;

	@Autowired
	WebClient.Builder builder;

	@RequestMapping("/laptop-info-data")
	private List<Laptop> getAllLaptops() throws RestClientException, URISyntaxException 
	{

		

		ResponseEntity<StudentBean[]> beans = template.getForEntity(new URI("http://student-info:8081/students"), StudentBean[].class);
		StudentBean[] beanOfStuBeans= beans.getBody();
		List<StudentBean> studentBeans = Arrays.asList(beanOfStuBeans);
		return studentBeans.stream()
				.map((student) -> new Laptop(student.getId(), student.getName(), "Lenova", "Octa Core Cpu"))
				.collect(Collectors.toList());
		
		/*
		StudentBean[] beanOfStuBeans = builder.build().get()
				.uri("http://localhost:8081/students").retrieve()
				.bodyToMono(StudentBean[].class).block();
		
		List<StudentBean> studentBeans = Arrays.asList(beanOfStuBeans);
		return studentBeans.stream()
				.map((student) -> new Laptop(student.getId(), student.getName(), "Lenova", "Octa Core Cpu"))
				.collect(Collectors.toList());
        */
	}

}
